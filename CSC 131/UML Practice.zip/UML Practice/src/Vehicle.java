import java.util.*;
public class Vehicle {
    private String make;
    private String model;
    private List<Passenger> passengers;
    private Engine engine;

    public String getMake() {
        return make;
    }
    public void setMake(String Make){
        this.make=make;
    }
    public String getModel(){
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public List<Passenger> getPassengers(){
        return passengers;
    }
    public void addPassenger(Passenger passenger){

    }
    public void removePassenger(Passenger passenger){

    }
    public Engine getEngine() {
        return engine;
    }
    public void setEngine(Engine engine) {
        this.engine = engine;
    }
    public void start(){

    }
    public void stop(){

    }
    public void accelerate(){

    }
    public void decelerate(){

    }
}
