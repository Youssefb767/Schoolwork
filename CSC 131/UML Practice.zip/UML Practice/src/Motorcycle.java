public class Motorcycle extends Vehicle{
    private String flameColor;

    public String getFlameColor() {
        return flameColor;
    }
    public void setFlameColor(String flameColor) {
        this.flameColor = flameColor;
    }

    public void popAWheelie(){

    }
}
