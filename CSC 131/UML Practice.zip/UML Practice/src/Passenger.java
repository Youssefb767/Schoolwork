public class Passenger extends insideVehicle{
    private String name;
    private String address;
    private String phoneNumber;
    private int birthYear;


}
