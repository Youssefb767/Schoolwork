public class Racer extends insideVehicle{
    private int racerID;
    private int racesWon;

    public int getRacerID() {
        return racerID;
    }
    public void setRacerID(int racerID) {
        this.racerID = racerID;
    }
    public int getRacesWon() {
        return racesWon;
    }
    public void setRacesWon(int racesWon) {
        this.racesWon = racesWon;
    }
}
