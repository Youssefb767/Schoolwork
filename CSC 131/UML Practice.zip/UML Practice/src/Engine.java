public class Engine extends Vehicle{
    private String manufacturer;
    private int year;
    private boolean isElectric;

    public String getManufacturer() {
        return manufacturer;
    }
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }
    public int getYear() {
        return year;
    }
    public void setYear(int year) {
        this.year = year;
    }
    public boolean isElectric() {
        return isElectric;
    }
    public void setElectric(boolean electric) {
        isElectric = electric;
    }
    public void start(){

    }
    public void stop(){

    }
    public void accelerate(){

    }
    public void decelerate(){

    }
}
