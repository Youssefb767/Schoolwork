public class Car extends Vehicle{
    private boolean hasAirConditioning;
    private String licensePlateNumber;
    public boolean hasAirconditioning(){
        return hasAirConditioning;
    }
    public void setHasAirConditioning(boolean hasAirConditioning){
        this.hasAirConditioning = hasAirConditioning;
    }
    public String getLicensePlateNumber(){
        return licensePlateNumber;
    }
    public void setLicensePlateNumber(String licensePlateNumber){
        this.licensePlateNumber = licensePlateNumber;
    }
}
