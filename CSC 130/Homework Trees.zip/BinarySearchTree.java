/*
Youssef Boujebha
3/13/23
Homework Trees Assignment
*/

import java.util.ArrayList;
import java.util.Stack;
public class BinarySearchTree<S extends Comparable> {
    private BinaryNode root;
    public BinarySearchTree(){
        root = null;
    }
    public boolean isEmpty(BinaryNode<S> TreeRoot){  //Variable for tracking if the tree is empty
        return TreeRoot == null;
    }
    public BinaryNode<S> emptyTree(){
        return null;
    }
    public class BinaryNode<S extends Comparable>{      //Class for the binary nodes
    private BinaryNode<S> left;     //Left node
    private BinaryNode<S> right;    //Right node
    private S key;               //Key for sorting the nodes

        public S getKey() {
            return key;
        }

        public BinaryNode(S key){
            this.key = key;
        }

        public BinaryNode<S> getRight() {
            return right;
        }

        public BinaryNode<S> getLeft() {
            return left;
        }
        public BinaryNode<S> KeyInsert(S element, BinaryNode<S> root){
            if (root == null){      //Checks if the root is empty
                return new BinaryNode(key);
            }
            int compare = element.compareTo(root.key);      //Creates a variable to compare the integers
            if(compare <= 0){       //Compares the new entry to see whether it should go to the left or the right of the node
                root.left = KeyInsert(element, root.left);
            } else{
                root.right = KeyInsert(element, root.right);
            }
            return root;
        }
    }
        //Start of the binary search tree class
    public BinaryNode<S> KeyInsert(S key, BinaryNode<S> TreeRoot){ //Sets the root equal to the key
        TreeRoot = TreeRoot.KeyInsert(key, TreeRoot);
        return TreeRoot;
    }

    public S RootKey(BinaryNode<S> TreeRoot){       //Returns null if the tree is empty and the key if it's not
        return (isEmpty(TreeRoot) ? null : TreeRoot.getKey());
    }

    public BinaryNode<S> getRight(BinaryNode<S> TreeRoot){
        return((isEmpty(TreeRoot) ? null : TreeRoot.getRight()));  //gets the right node if the root isn't empty
    }
    public BinaryNode<S> getLeft(BinaryNode<S> TreeRoot){   //Gets the left node if the root isn't empty
        return(isEmpty(TreeRoot) ? null : TreeRoot.getLeft());
    }

    public S[] Traverse(BinaryNode<S> TreeRoot){     //Tree traversal
        BinaryNode<S> Current = TreeRoot;
        ArrayList<S> arrayList = new ArrayList<>();
        Stack<BinaryNode<S>> stack = new Stack<>();

        while (Current != null || !stack.empty()){  //Pushes the node until it becomes the left leaf
            while (Current !=null){
                stack.push(Current);
                Current = Current.getLeft();
            }
            Current = stack.pop(); //Pops the key
            arrayList.add(Current.getKey());

            Current = Current.getRight();   //Checks the right subtree
        }
        return (S[]) arrayList.toArray();
    }

}