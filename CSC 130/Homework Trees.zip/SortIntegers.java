public class SortIntegers { //A class for sorting integers
    public int[] ArraySorter(int[] Input){
        int[] Output = null;
        BinarySearchTree<Integer> BinarySearchTree = new BinarySearchTree<>();
        BinaryNode<Integer> TreeRoot = BinarySearchTree.emptyTree();

        for(Integer element : Input){
            TreeRoot = BinarySearchTree.KeyInsert(element, TreeRoot);
        }
        Output = BinarySearchTree.Traverse(TreeRoot);
        return Output;
    }
}
