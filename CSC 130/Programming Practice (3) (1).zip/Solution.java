class Solution {
    Set<String> characters = Set.of("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z");
    public static void main(String args[]){
    }
    public boolean isPalindrome(String A){
        StringBuilder sb = new StringBuilder();
        for (char c : A.toLowerCase().toCharArray()){
            if (characters.contains(Character.toString(c))) {
                sb.append(c);
            }
        }
        for (int i = 0, n = sb.length() - 1; i < sb.length();i++,n--){
            if (sb.charAt(i) != sb.charAt(n)) {
                return false;
            }
        }
        return true;
    }
}