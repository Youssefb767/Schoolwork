import java.util.*;
public class AdjacencyList {
    private int numVertices;
    private Map<Integer, List<Integer>> adjacencyList;
    public AdjacencyList(int numVertices){
        this.numVertices = numVertices;
        this.adjacencyList = new HashMap<>();
        for (int i = 0; i < numVertices; i++) {
            adjacencyList.put(i, new LinkedList<>());
        }
    }

    public void addEdge(int i, int j){
        adjacencyList.get(i).add(j);
    }

    public void removeEdge(int i, int j){
        adjacencyList.get(i).remove(j);
    }

    public boolean hasEdge(int i, int j){
        return adjacencyList.get(i).contains(j);
    }

    public int getNumVertices(){
        return numVertices;
    }

    public Map<Integer, List<Integer>> getAdjacencyList(){
        return adjacencyList;
    }

    public static void main(String[]args){
        AdjacencyList graphOne = new AdjacencyList(6); //Graph One
        // A B C D E F
        graphOne.addEdge(0, 1); // AB
        graphOne.addEdge(1, 2); //BC
        graphOne.addEdge(1, 3); // BD
        graphOne.addEdge(2, 2); //CB
        graphOne.addEdge(2, 4); // CE
        graphOne.addEdge(3, 2); //DB
        graphOne.addEdge(3, 4); //DE
        graphOne.addEdge(4, 2); //EC
        graphOne.addEdge(4, 3); //ED
        graphOne.addEdge(4, 5); //EF
        graphOne.addEdge(5, 4); //FE

        AdjacencyList graphTwo = new AdjacencyList(5); //Graph two
        // A B D F N, A = 0
        graphTwo.addEdge(0, 1); // AB
        graphTwo.addEdge(0, 2); // AD
        graphTwo.addEdge(0, 3); // AF
        graphTwo.addEdge(0, 4); // AN
        graphTwo.addEdge(1, 0); // BA
        graphTwo.addEdge(1, 2); // BD
        graphTwo.addEdge(1, 3); // BF
        graphTwo.addEdge(1, 4); // BN
        graphTwo.addEdge(2, 0); // DA
        graphTwo.addEdge(2, 1); // DB
        graphTwo.addEdge(3, 0); // FA
        graphTwo.addEdge(3, 1); // FB
        graphTwo.addEdge(3, 4); // FN
        graphTwo.addEdge(4, 0); // NA
        graphTwo.addEdge(4, 1); // NB
        graphTwo.addEdge(4, 3); // NF
    }
}

