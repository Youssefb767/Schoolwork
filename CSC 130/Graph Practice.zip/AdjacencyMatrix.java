public class AdjacencyMatrix{
    private int[][] matrix;
    private int numVertices;

    public AdjacencyMatrix(int numVertices){
        this.numVertices = numVertices;
        this.matrix = new int[numVertices][numVertices];
    }

    public void addEdge(int i, int j, int weight){ //Extra Parameter to allow for weight input
        matrix[i][j] = 1;
    }

    public boolean hasEdge(int i, int j){
        return matrix[i][j] == 1;
    }

    public void removeEdge(int i, int j){
        matrix[i][j] = 0;
    }
    public int[][] getMatrix(){
        return matrix;
    }
    public int getNumVertices(){
        return numVertices;
    }

    public static void main(String[] args){
        AdjacencyMatrix adjMatrixOne = new AdjacencyMatrix (6);    //First graph

        adjMatrixOne.addEdge(0, 1,1); // A to B
        adjMatrixOne.addEdge(1, 0,1); // B to A
        adjMatrixOne.addEdge(1, 2,1); // B to C
        adjMatrixOne.addEdge(1, 3,1); // B to D
        adjMatrixOne.addEdge(2, 1,1); // C to B
        adjMatrixOne.addEdge(2, 4,1); // C to E
        adjMatrixOne.addEdge(4, 2,1); // E to C
        adjMatrixOne.addEdge(4, 3,1); // E to D
        adjMatrixOne.addEdge(4, 5,1); // E to F
        adjMatrixOne.addEdge(3, 1,1); // D to B
        adjMatrixOne.addEdge(3, 4,1); // D to E
        adjMatrixOne.addEdge(5, 4,1); // F to E

        //Prints the first matrix
        int[][] matrix = adjMatrixOne.getMatrix();
        System.out.print("  ");
        for (int i = 0; i < adjMatrixOne.getNumVertices(); i++) {
            System.out.print((char)('a' + i) + " ");
        }
        System.out.println();
        for (int i = 0; i < adjMatrixOne.getNumVertices(); i++) {
            System.out.print((char)('a' + i) + " ");
            for (int j = 0; j < adjMatrixOne.getNumVertices(); j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }

        AdjacencyMatrix adjMatrixTwo = new AdjacencyMatrix (5);    //Second graph
        // A B D F N A=0
        adjMatrixTwo.addEdge(0, 1, 14); // A to B
        adjMatrixTwo.addEdge(1,3, 13); // B to F
        adjMatrixTwo.addEdge(1, 2, 23); // B to D
        adjMatrixTwo.addEdge(2, 0, 5); // D to A
        adjMatrixTwo.addEdge(2, 0, 43); // F to A
        adjMatrixTwo.addEdge(3, 4, 33); // F to N
        adjMatrixTwo.addEdge(4, 0, 33); // N to A
        adjMatrixTwo.addEdge(4, 1, 22); // N to B
        adjMatrixTwo.addEdge(4, 3,11); // N to F

        //Prints the second matrix
        int[][] matrixTwo = adjMatrixTwo.getMatrix();
        System.out.print("  ");
        for (int i = 0; i < adjMatrixTwo.getNumVertices(); i++){
            System.out.print((char)('a' + i) + " ");
        }
        System.out.println();
        for (int i = 0; i < adjMatrixTwo.getNumVertices(); i++){
            System.out.print((char)('a' + i) + " ");
            for (int j = 0; j < adjMatrixTwo.getNumVertices(); j++){
                System.out.print(matrixTwo[i][j] + " ");
            }
            System.out.println();
        }
    }
}