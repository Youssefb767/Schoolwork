package SlRenderer;

import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;

import java.nio.FloatBuffer;

import static org.lwjgl.opengl.GL20.*;

public class slShaderManager {
    private int csProgram;
    private final String vertexShaderFilename;
    private final String fragmentShaderFilename;

    public slShaderManager(String vs_filename, String fs_filename) {
        this.vertexShaderFilename = "shaders/" + vs_filename;
        this.fragmentShaderFilename = "shaders/" + fs_filename;
    }

    public int compile_shader() {
        int vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
        int fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

        glShaderSource(vertexShaderId, vertexShaderFilename);
        glShaderSource(fragmentShaderId, fragmentShaderFilename);

        glCompileShader(vertexShaderId);
        glCompileShader(fragmentShaderId);

        csProgram = glCreateProgram();
        glAttachShader(csProgram, vertexShaderId);
        glAttachShader(csProgram, fragmentShaderId);

        glLinkProgram(csProgram);
        glValidateProgram(csProgram);
        return csProgram;
    }

    public void set_shader_program() {
        glUseProgram(csProgram);
    }

    public static void detach_shader() {
        glUseProgram(0);
    }

    public void loadMatrix4f(String strMatrixName, Matrix4f my_mat4) {
        int location = glGetUniformLocation(csProgram, strMatrixName);
        FloatBuffer buffer = BufferUtils.createFloatBuffer(16);
        my_mat4.get(buffer);
        glUniformMatrix4fv(location, false, buffer);
    }
}