package csc133;


import javax.swing.*;
import java.io.File;

import static SlRenderer.slSingleBatchRenderer.render;

public class Main {
    public static void main(String[] args) {
        render();
    }
}








