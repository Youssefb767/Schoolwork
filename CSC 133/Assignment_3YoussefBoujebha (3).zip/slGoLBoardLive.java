/*  IMPORTANT: I changed the package so that it works with my file structure!
    Change it back to "csc133" if there's an error                         */
package src.main.java.csc133;

public class slGoLBoardLive extends slGoLBoard {
    // Constructor for the main class
    public slGoLBoardLive(int numRows, int numCols) {
        super(numRows, numCols);
    }

    // return how many live cells are in the updated board -- given code from assignment
    @Override
    public int updateNextCellArray() {
        int retVal = 0;

        int nln = 0;  // Number Live Neighbors
        boolean ccs = true; // Current Cell Status
        for (int row = 0; row < NUM_ROWS; ++row) {
            for (int col = 0; col < NUM_COLS; ++col) {
                ccs = liveCellArray[row][col];
                nln = countLiveTwoDegreeNeighbors(row, col);
                if (!ccs && nln == 3) {
                    nextCellArray[row][col] = true;
                    ++retVal;
                } else {
                    // Current Cell Status is true
                    if (nln < 2 || nln > 3) {
                        nextCellArray[row][col] = false;
                    } else {
                        // nln == 2 || nln == 3
                        nextCellArray[row][col] = true;
                        ++retVal;
                    }
                }
            }  // for (int row = 0; ...)
        }  //  for (int col = 0; ...)

        boolean[][] tmp = liveCellArray;
        liveCellArray = nextCellArray;
        nextCellArray = tmp;

        return retVal;
    }

    @Override
    public int countLiveTwoDegreeNeighbors(int row, int col) {
        int myCount = 0;
        for (int i = row - 1; i <= row + 1; i++) {
            for (int j = col - 1; j <= col + 1; j++) {
                if (i >= 0 && i < NUM_ROWS && j >= 0 && j < NUM_COLS && !(i == row && j == col)) {
                    if (liveCellArray[i][j]) {
                        myCount++;
                    }
                }
            }
        }
        return myCount;
    }
}