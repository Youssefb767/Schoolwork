package csc133;

public class spot {

}
