// Main.java
package csc133;

import SlRenderer.slSingleBatchRenderer;

public class Main {
    public static void main(String[] args) {
        slSingleBatchRenderer myRenderer = new slSingleBatchRenderer();
        myRenderer.render();
    }
}