package csc133;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class slCamera {
    private Matrix4f viewMatrix;
    private Vector3f defaultLookFrom;
    private Vector3f defaultLookAt;
    private Vector3f defaultUpVector;
    private float f_left;
    private float f_right;
    private float f_bottom;
    private float f_top;
    private float f_near;
    private float f_far;
    private Vector3f curLookFrom;
    private Vector3f curLookAt;
    private Vector3f curUpVector;
    private Matrix4f projectionMatrix;

    public slCamera() {
        this.defaultLookFrom = new Vector3f();
        this.defaultLookAt = new Vector3f();
        this.defaultUpVector = new Vector3f(0, 1, 0); // Assuming default up vector is (0, 1, 0)
        this.curLookFrom = new Vector3f();
        this.curLookAt = new Vector3f();
        this.curUpVector = new Vector3f();
        this.viewMatrix = new Matrix4f();
        this.projectionMatrix = new Matrix4f();
    }

    public slCamera(Vector3f camera_position) {
        this();
        this.defaultLookFrom.set(camera_position);
    }

    private void setCamera() {
        viewMatrix = new Matrix4f().identity();
        projectionMatrix = new Matrix4f().identity();
    }

    public void setProjectionOrtho() {
        setProjectionOrtho(-100, 100, -100, 100, 0, 10);
    }

    public void setProjectionOrtho(float left, float right, float bottom, float top, float near, float far) {
        this.f_left = left;
        this.f_right = right;
        this.f_bottom = bottom;
        this.f_top = top;
        this.f_near = near;
        this.f_far = far;

        projectionMatrix.setOrtho(left, right, bottom, top, near, far);
    }

    public Matrix4f getViewMatrix() {
        return viewMatrix;
    }

    public Matrix4f getProjectionMatrix() {
        return projectionMatrix;
    }
}
