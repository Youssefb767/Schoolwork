package SlRenderer;

import org.joml.Vector3f;
import org.lwjgl.BufferUtils;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import static org.lwjgl.opengl.ARBVertexArrayObject.glBindVertexArray;
import static org.lwjgl.opengl.ARBVertexArrayObject.glGenVertexArrays;
import static org.lwjgl.opengl.GL20.*;
import static csc133.spot.*;

public class slLevelSceneEditor {

    private final Vector3f my_camera_location = new Vector3f(0, 0, 0.0f);
    private slShaderManager testShader;
    private slTextureManager testTexture;

    private float xmin = POLY_OFFSET, ymin = POLY_OFFSET, zmin = 0.0f, xmax = xmin+ POLYGON_LENGTH,
                            ymax = ymin+ POLYGON_LENGTH, zmax = 0.0f;

    private final float uvmin = 0.0f, uvmax = 1.0f;

    private final float [] vertexArray = {
            // vertices -        colors                   UV coordinates
            xmin, ymin, zmin,   1.0f, 0.0f, 1.0f, 1.0f,  uvmin, uvmax, // bottom left
            xmax, ymin, zmin,   1.0f, 1.0f, 1.0f, 1.0f,  uvmax, uvmax, // bottom right
            xmax, ymax, zmin,   1.0f, 1.0f, 1.0f, 1.0f,  uvmax, uvmin, // top right
            xmin, ymax, zmin,   1.0f, 1.0f, 1.0f, 1.0f,  uvmin, uvmin  // top left
            //Color values don't actually change anything yet
    };

    private final int[] rgElements = {2, 1, 0, //top triangle
                                      0, 1, 3 // bottom triangle
    };
    int positionStride = 3;
    int colorStride = 4;
    int textureStride = 2;
    int vertexStride = (positionStride + colorStride + textureStride) * Float.BYTES;

    private int vaoID, vboID, eboID;
    final private int  vpoIndex = 0, vcoIndex = 1, vtoIndex = 2;

    slCamera my_camera;

    public slLevelSceneEditor() {

    }

    public void init() {
        my_camera = new slCamera(my_camera_location);
        my_camera.setOrthoProjection();

        testShader =
                new slShaderManager("vs_texture_1.glsl", "fs_texture_1.glsl");

        testShader.compile_shader();

        //Texture manager object
        testTexture = new slTextureManager("assets/images/MarioWithGun2.PNG");
        // Bind the texture to the active texture unit using the slTextureManager class
        testTexture.bind_texture();

        vaoID = glGenVertexArrays();
        glBindVertexArray(vaoID);

        FloatBuffer vertexBuffer = BufferUtils.createFloatBuffer(vertexArray.length);
        vertexBuffer.put(vertexArray).flip();

        vboID = glGenBuffers();
        glBindBuffer(GL_ARRAY_BUFFER, vboID);
        // GL_STATIC_DRAW good for now; we can later change to dynamic vertices:
        glBufferData(GL_ARRAY_BUFFER, vertexBuffer, GL_STATIC_DRAW);

        IntBuffer elementBuffer = BufferUtils.createIntBuffer(rgElements.length);
        elementBuffer.put(rgElements).flip();

        eboID = glGenBuffers();
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, eboID);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, elementBuffer, GL_STATIC_DRAW);

        glVertexAttribPointer(vpoIndex, positionStride, GL_FLOAT, false, vertexStride, 0);
        glEnableVertexAttribArray(vpoIndex);

        glVertexAttribPointer(vcoIndex, colorStride, GL_FLOAT, false, vertexStride,
                                                            positionStride * Float.BYTES);
        glEnableVertexAttribArray(vcoIndex);

        //VTO Index
        glVertexAttribPointer(vtoIndex, textureStride, GL_FLOAT, false, vertexStride,
                (positionStride + colorStride) * Float.BYTES);
        glEnableVertexAttribArray(vtoIndex);
    }

    public void update(float dt) {

        //Camera movement
        my_camera.relativeMoveCamera(dt*alpha, dt*alpha);
        if (my_camera.getCurLookFrom().x < -FRUSTUM_RIGHT) {
            my_camera.restoreCamera();
            my_camera.setOrthoProjection();
        }

        // Set the shader program to use
        testShader.set_shader_program();
        testShader.loadTexture("TEX_SAMPLER",0);

        // Load the projection and view matrices into the shade
        testShader.loadMatrix4f("uProjMatrix", my_camera.getProjectionMatrix());
        testShader.loadMatrix4f("uViewMatrix", my_camera.getViewMatrix());

        // Bind the Vertex Array Object that our data is associated with
        glBindVertexArray(vaoID);

        // Enable the vertex attribute arrays
        glEnableVertexAttribArray(vpoIndex);
        glEnableVertexAttribArray(vcoIndex);
        glEnableVertexAttribArray(vtoIndex);

        // Draw the elements
        glDrawElements(GL_TRIANGLES, rgElements.length, GL_UNSIGNED_INT, 0);

        // Disable the vertex attribute arrays
        glDisableVertexAttribArray(vpoIndex);
        glDisableVertexAttribArray(vcoIndex);
        glDisableVertexAttribArray(vtoIndex);

        // Unbind the Vertex Array Object
        glBindVertexArray(0);

        // Detach the shader program
        testShader.detach_shader();
    }

}
