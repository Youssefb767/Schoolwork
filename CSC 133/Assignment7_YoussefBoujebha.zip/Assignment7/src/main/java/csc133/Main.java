package csc133;


import javax.swing.*;
import java.io.File;


public class Main {
    public static void main(String[] args) {
        slWindow window = slWindow.get();
        window.run();
    }
}








